package com.bserc.reelmonster

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var countText: TextView
    private lateinit var timeText: TextView
    private lateinit var weekBox: LinearLayout
    private val purple = Color.rgb(111, 78, 190)
    private val ink = Color.rgb(39, 35, 55)
    private val muted = Color.rgb(111, 105, 128)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::countText.isInitialized) refreshStats()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float, color: Int = ink, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(Color.rgb(248, 246, 253))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(text("👾  REEL MONSTER", 25f, purple, true))
        root.addView(text("A tiny monster for your scrolling habit", 14f, muted).apply {
            setPadding(0, dp(4), 0, dp(18))
        })
        val hero = card()
        hero.addView(text("Your monster is hungry!", 21f, ink, true))
        hero.addView(text("Watch a reel? Tap the floating monster once. It grows as your count increases.", 14f, muted).apply {
            setPadding(0, dp(8), 0, dp(8))
        })
        root.addView(hero)

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val cCard = card(); val tCard = card()
        countText = text("0", 27f, purple, true)
        timeText = text("0 min", 22f, purple, true)
        cCard.addView(text("TODAY'S REELS", 11f, muted, true)); cCard.addView(countText)
        tCard.addView(text("EST. TIME LOST", 11f, muted, true)); tCard.addView(timeText)
        stats.addView(cCard, LinearParams(0, -2, 1f).apply { marginEnd = dp(6) })
        stats.addView(tCard, LinearParams(0, -2, 1f).apply { marginStart = dp(6) })
        root.addView(stats)

        val actions = card()
        actions.addView(text("Start counting", 18f, ink, true))
        actions.addView(text("Enable the floating bubble, then open Instagram or YouTube. Tap the monster after each reel.", 13f, muted).apply {
            setPadding(0, dp(6), 0, dp(10))
        })
        actions.addView(button("Enable floating monster") { enableOverlay() })
        actions.addView(button("Stop floating monster") {
            stopService(Intent(this, MonsterOverlayService::class.java))
            Toast.makeText(this, "Monster hidden", Toast.LENGTH_SHORT).show()
        })
        root.addView(actions)

        val week = card()
        week.addView(text("LAST 7 DAYS", 16f, ink, true))
        weekBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        week.addView(weekBox)
        root.addView(week)

        root.addView(button("Reset today's count") {
            StatsStore.clearToday(this)
            refreshStats()
            Toast.makeText(this, "Today's count reset", Toast.LENGTH_SHORT).show()
        })
        root.addView(text("Privacy: counts are stored on this phone. No account, internet or analytics are used.", 12f, muted).apply {
            setPadding(0, dp(14), 0, 0)
        })
        refreshStats()
    }

    private fun LinearParams(w: Int, h: Int, weight: Float) =
        LinearLayout.LayoutParams(w, h, weight)

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        setBackgroundColor(Color.WHITE)
        elevation = dp(2).toFloat()
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(13)
        layoutParams = lp
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Allow 'Display over other apps', then return and tap Enable again.", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this, MonsterOverlayService::class.java))
        else startService(Intent(this, MonsterOverlayService::class.java))
        Toast.makeText(this, "Monster activated!", Toast.LENGTH_SHORT).show()
    }

    private fun refreshStats() {
        countText.text = StatsStore.totalToday(this).toString()
        timeText.text = StatsStore.formatDuration(StatsStore.estimatedSeconds(this))
        weekBox.removeAllViews()
        StatsStore.lastSevenDays(this).forEach { (date, count) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, dp(7))
            }
            row.addView(text(date, 13f, muted), LinearParams(0, -2, 1f))
            row.addView(text("$count reels", 13f, purple, true))
            weekBox.addView(row)
        }
    }
}
