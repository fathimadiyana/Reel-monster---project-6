package com.bserc.reelmonster

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object StatsStore {
    private const val PREF = "reel_monster_stats"
    private const val ESTIMATED_SECONDS_PER_REEL = 30L
    private fun prefs(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    fun count(context: Context, key: String = todayKey()): Int = prefs(context).getInt("count_$key", 0)
    fun tap(context: Context): Int {
        val p = prefs(context)
        val key = todayKey()
        val next = p.getInt("count_$key", 0) + 1
        p.edit().putInt("count_$key", next).apply()
        return next
    }
    fun totalToday(context: Context) = count(context)
    fun estimatedSeconds(context: Context, key: String = todayKey()) =
        count(context, key).toLong() * ESTIMATED_SECONDS_PER_REEL
    fun lastSevenDays(context: Context): List<Pair<String, Int>> {
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return (6 downTo 0).map { offset ->
            val date = Date(System.currentTimeMillis() - offset * 24L * 60L * 60L * 1000L)
            val key = fmt.format(date)
            key to count(context, key)
        }
    }
    fun clearToday(context: Context) {
        prefs(context).edit().remove("count_${todayKey()}").apply()
    }
    fun formatDuration(seconds: Long): String {
        val mins = seconds / 60
        return if (mins < 60) "$mins min" else "${mins / 60}h ${mins % 60}m"
    }
}
