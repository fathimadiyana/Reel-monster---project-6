package com.bserc.reelmonster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MonsterOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: LinearLayout? = null
    private var counter: TextView? = null
    private var face: TextView? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onCreate() {
        super.onCreate()
        createNotification()
        startForeground(7, notification())
        showBubble()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("monster", "Reel Monster", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "monster")
                .setContentTitle("Reel Monster is active")
                .setContentText("Tap the floating monster after each reel.")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Reel Monster is active")
                .setContentText("Tap the floating monster after each reel.")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true).build()
        }
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(111, 78, 190))
        }
        face = TextView(this).apply {
            text = "👾"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        counter = TextView(this).apply {
            text = StatsStore.totalToday(this@MonsterOverlayService).toString()
            textSize = 13f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        container.addView(face)
        container.addView(counter)
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 180
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        container.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                    params.x = (startX - dx).coerceAtLeast(0)
                    params.y = (startY + dy).coerceAtLeast(0)
                    windowManager.updateViewLayout(container, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) increment()
                    true
                }
                else -> true
            }
        }
        bubble = container
        windowManager.addView(container, params)
    }

    private fun increment() {
        val count = StatsStore.tap(this)
        counter?.text = count.toString()
        face?.textSize = (30f + (count / 5).coerceAtMost(20))
        face?.text = when {
            count >= 50 -> "👹"
            count >= 25 -> "😈"
            count >= 10 -> "👾"
            else -> "👻"
        }
        val message = when {
            count % 25 == 0 -> "I'm huge! $count reels today!"
            count % 10 == 0 -> "Nom nom! $count reels!"
            count % 5 == 0 -> "Keep an eye on that scroll!"
            else -> "Reel counted: $count"
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        bubble?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
