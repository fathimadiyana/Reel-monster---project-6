# Reel Monster — Prompt Log
BSERC GenAI Internship · Week 2 · Project 6 · Level 1

1. **Plan:** Build an Android-only, offline, no-login Level 1 app called Reel Monster. A draggable floating monster overlay stays visible over Instagram and YouTube. Level 1 counting is manual: each tap increments the reel count. Persist counts across restarts and show today's count, estimated time lost and the last seven days.

2. **Android setup:** Create a native Kotlin Android project with a launcher dashboard, a foreground service for the floating overlay, and the Android Display over other apps permission. Avoid third-party libraries and network access.

3. **Overlay:** Implement a draggable always-on-top bubble with a monster emoji and count. A tap increments the daily count. The monster changes size/appearance and shows playful feedback as the count increases.

4. **Persistence and dashboard:** Store per-day counts in SharedPreferences. Display today's total, a seven-day history and an estimated time cost using a clearly documented estimate of 30 seconds per manually counted reel.

5. **Review:** Check Android permission flow, service start/stop, drag vs tap handling, persistence after app restart, date-based daily history, and offline operation. Document that Level 1 relies on manual taps and does not automatically detect reels.
